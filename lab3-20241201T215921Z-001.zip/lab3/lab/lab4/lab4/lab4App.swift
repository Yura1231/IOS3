//
//  lab4App.swift
//  lab4
//
//  Created by IPZ-31 on 19.11.2024.
//

import SwiftUI

@main
struct lab4App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
